export default function FleetGallery() {
  const fleetImages = [
    {
      src: "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      alt: "Modern cargo truck"
    },
    {
      src: "https://images.unsplash.com/photo-1553729459-efe14ef6055d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      alt: "Fleet of trucks in logistics yard"
    },
    {
      src: "https://images.unsplash.com/photo-1566576912321-d58ddd7a6088?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      alt: "Warehouse with loading bays"
    },
    {
      src: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      alt: "Professional truck driver"
    },
    {
      src: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      alt: "Mini truck urban delivery"
    },
    {
      src: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      alt: "GPS tracking system"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Fleet</h2>
          <p className="text-xl text-gray-600">Modern, well-maintained vehicles for safe cargo transportation</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {fleetImages.map((image, index) => (
            <img
              key={index}
              src={image.src}
              alt={image.alt}
              className="rounded-xl shadow-lg w-full h-64 object-cover hover:shadow-xl transition-shadow"
            />
          ))}
        </div>
      </div>
    </section>
  );
}
