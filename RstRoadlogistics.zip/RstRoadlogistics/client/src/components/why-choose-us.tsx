import { Shield, Clock, Users, DollarSign } from "lucide-react";

export default function WhyChooseUs() {
  const benefits = [
    {
      icon: Shield,
      title: "Secure & Insured",
      description: "Full insurance coverage and secure handling of your valuable cargo",
      color: "text-primary"
    },
    {
      icon: Clock,
      title: "On-Time Delivery",
      description: "Punctual delivery with real-time GPS tracking and updates",
      color: "text-secondary"
    },
    {
      icon: Users,
      title: "Professional Team",
      description: "Experienced drivers and logistics experts at your service",
      color: "text-accent"
    },
    {
      icon: DollarSign,
      title: "Competitive Rates",
      description: "Transparent pricing with no hidden costs or surprises",
      color: "text-primary"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose RST ROADLINES?</h2>
          <p className="text-xl text-gray-600">Your trusted partner for reliable cargo transportation</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => {
            const IconComponent = benefit.icon;
            return (
              <div key={index} className="text-center p-6">
                <div className="bg-primary bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <IconComponent className={`h-8 w-8 ${benefit.color}`} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
